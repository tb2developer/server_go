#!/bin/bash

sudo docker run -p 3434:3434 -it server_go